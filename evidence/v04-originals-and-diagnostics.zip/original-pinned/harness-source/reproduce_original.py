from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'build/v04-original-pinned';out.mkdir();checkout=out/'checkout';checkout.mkdir()
sha='d64bef31fb35800be8af60e6d5a63d80a6afd020';hashes={}
names=subprocess.check_output(['git','ls-tree','-r','--name-only',sha,'guardian','runtime-lock.json'],cwd=root).decode().splitlines()
for name in names:
 raw=subprocess.check_output(['git','show',sha+':'+name],cwd=root);p=checkout/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);hashes[name]=hashlib.sha256(raw).hexdigest()
shutil.copytree(root/'tools',checkout/'tools',ignore=shutil.ignore_patterns('__pycache__'))
(checkout/'build/runtime').mkdir(parents=True);shutil.copyfile(root/'build/runtime/python-3.12.10-embed-amd64.zip',checkout/'build/runtime/python-3.12.10-embed-amd64.zip')
commands=[]
for name in ('runtime_after_write','crash_written'):
 dest=out/name;argv=[sys.executable,'-B',str(checkout/'tools/v04_campaign.py'),'--out',str(dest),'--witness',name,'--legacy-dispatch']
 p=subprocess.run(argv,capture_output=True);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
 r=json.loads((dest/name/'witness.json').read_bytes());commands.append({'argv':argv,'exit_code':p.returncode,'oracle':r})
 if p.returncode!=1 or r.get('control_broken') or r['passed']:raise RuntimeError('Original defect not reproduced')
 expected={'restart_preserves_ambiguity'}|({'no_false_nonexecution'} if name=='runtime_after_write' else set())
 if {k for k,v in r['checks'].items() if not v}!=expected:raise RuntimeError('Unexpected original failures')
(out/'report.json').write_bytes(json.dumps({'production_sha':sha,'production_sha256':hashes,'commands':commands,'expected_defects_reproduced':True,'harness_source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (checkout/'tools').glob('v04*.py')}},indent=2,sort_keys=True).encode()+b'\n')
print('Two original defects independently reproduced against pinned production bytes')
