import json
from pathlib import Path
import platform
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
out = root/'build/v05-serial-history'
out.mkdir(exist_ok=False)
rows = []
for version, tool in [('v02', 'v02_mutations.py'), ('v03', 'v03_mutations.py'), ('v04', 'v04_mutations.py')]:
    for mode, flags in [('repeat', []), ('optimized', ['-O'])]:
        name = version+'-'+mode
        argv = [sys.executable, '-B', *flags, 'tools/'+tool, '--out', str(out/name)]
        start = time.perf_counter()
        p = subprocess.run(argv, cwd=root, capture_output=True)
        (out/(name+'.stdout')).write_bytes(p.stdout); (out/(name+'.stderr')).write_bytes(p.stderr)
        report = out/name/'report.json'
        row = {'name': name, 'argv': argv, 'exit_code': p.returncode, 'seconds': time.perf_counter()-start,
               'counts': json.loads(report.read_bytes()).get('counts') if report.exists() else None}
        rows.append(row)
        (out/'commands.json').write_bytes(json.dumps(rows, indent=2).encode()+b'\n')
        print(json.dumps(row), flush=True)
result = {'schema': 'guardian.serial-historical-replay.v05',
          'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),
          'python': sys.version, 'platform': platform.platform(),
          'passed': all(r['exit_code']==0 for r in rows), 'commands': rows,
          'earlier_concurrent_failures_preserved': True}
(out/'report.json').write_bytes(json.dumps(result, indent=2).encode()+b'\n')
raise SystemExit(not result['passed'])
