"""Diagnostic selection only; unchanged campaign, guards and classifier."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'demo/real-agent'))
import mutations

p=argparse.ArgumentParser();p.add_argument('--runtime',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
mutations.MUTATIONS={name:row for name,row in mutations.MUTATIONS.items() if name in ('post_write_outcome','resource_acl')}
results=mutations.run(a.out,a.runtime.resolve())
(a.out/'selection.json').write_bytes(json.dumps({'reason':'Prior restored control produced a genuine model refusal; preserve original campaign and execute selected boundaries afresh.','selected':list(mutations.MUTATIONS),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},sort_keys=True,indent=2).encode()+b'\n')
raise SystemExit(any(r['classification']!='KILLED' for r in results))
