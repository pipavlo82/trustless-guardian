"""Read-only aggregation; requires completed reports, never fills missing results."""
import argparse,hashlib,json,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=a.root
def read(s):return json.loads((root/s).read_bytes())
def digest(s):return hashlib.sha256((root/s).read_bytes()).hexdigest()
top=read('report.json');v03=read('v03/report.json');v02=read('v03/v02/report.json');v0=read('v03/v02/v0/report.json')
units={};scenarios={};mutations={};semantic={};bypass={}
for mode in ('normal','repeat','optimized'):
 raw=(root/f'v03/v02/v0/unit-{mode}.stderr').read_text()
 units[mode]={'count':int(re.search(r'Ran (\d+) tests',raw)[1]),'passed':raw.rstrip().endswith('OK')}
 for version,loc,key in [('v0',f'v03/v02/v0/lab-{mode}/summary.json','policy_cases'),('v02',f'v03/v02/{mode}/report.json','cases'),('v03',f'v03/{mode}/report.json','scenarios'),('v04',f'{mode}/report.json','scenarios')]:
  r=read(loc)
  # v0 uses a named scenario array; don't infer counts from documentation.
  values=r.get(key,r.get('cases'))
  if values is None:raise ValueError((loc,list(r)))
  scenarios.setdefault(version,{})[mode]={'count':len(values),'passed':r['passed']}
  semantic.setdefault(version,{})[mode]=digest(str(Path(loc).with_name('semantic.json')))
 r=read(f'v03/v02/v0/lab-{mode}/summary.json')['bypass']
 bypass[mode]={'denied':sum(x['result']=='OS_REJECTED' for x in r['rows']),'positive':any(x['name']=='scratch_positive' and x['result']=='SUCCEEDED' for x in r['rows']),
  'unchanged':r['before_sha256']==r['after_sha256'],'completed':r['agent_completed']}
for version,normal in [('v0','v03/v02/v0/mutations/report.json'),('v02','v03/v02/mutations/report.json'),('v03','v03/mutations-normal/report.json'),('v04','mutations-normal/report.json')]:
 mutations[version]={'normal':read(normal)['counts']}
 for mode in ('repeat','optimized'):
  path=f'mutations-{mode}/report.json' if version=='v04' else f'{version}-mutations-{mode}/report.json'
  mutations[version][mode]=read(path)['counts']
out={'schema':'guardian.v04.aggregate.v0','checkout':read('checkout.json'),'passed':all(r['passed'] for r in (top,v03,v02,v0)),
 'units':units,'scenarios':scenarios,'mutations':mutations,'bypass':bypass,'semantic_sha256':semantic,
 'semantic_determinism':{v:len(set(h.values()))==1 for v,h in semantic.items()},'source_sha256':top['source_sha256'],
 'elapsed_command_seconds':sum(r['seconds'] for r in top['commands']),
 'outer_commands':top['commands'],'external_execution':'UNVERIFIABLE','independent_human_review':'NOT_COVERED'}
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_bytes(json.dumps(out,sort_keys=True,indent=2).encode()+b'\n')
print(json.dumps({k:out[k] for k in ('passed','units','scenarios','mutations','bypass','semantic_determinism','elapsed_command_seconds')}))
