import hashlib,json,subprocess
from pathlib import Path
base=Path('D:/PAVLO HQ/Workspaces/trustless-guardian-audit-20261024')
spec={
 'receiptos-verify':['LICENSE','src/core/verify-v2.mjs','src/core/claim-surface.mjs'],
 'verifiable-execution-claim-authorization':['LICENSE','src/integration/engine.py'],
 'recompute-kit':['LICENSE','research/chain-neutral-receipt-anchor-proof-v0/adapter.mjs'],
}
rows={}
for name,paths in spec.items():
 root=base/name
 def git(*a):return subprocess.check_output(['git',*a],cwd=root).decode().strip()
 rows[name]={'head':git('rev-parse','HEAD'),'origin_main':git('rev-parse','origin/main'),'status':git('status','--porcelain'),
  'files':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'native_execution':'NOT_COVERED','writes':False}
Path('build/v04-preflight/native-source-audit.json').write_bytes(json.dumps(rows,sort_keys=True,indent=2).encode()+b'\n')
print(json.dumps(rows))
