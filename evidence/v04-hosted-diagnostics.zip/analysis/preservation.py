import hashlib,json,subprocess
from pathlib import Path
root=Path('.');start='d64bef31fb35800be8af60e6d5a63d80a6afd020'
def sha(raw):return hashlib.sha256(raw).hexdigest()
files=json.loads(subprocess.check_output(['git','show',start+':artifacts.sha256.json']))
protected={p:h for p,h in files.items() if (p.startswith('evidence/') and p!='evidence/README.md') or p in ('LICENSE','THIRD_PARTY_NOTICES.md','runtime-lock.json','source-lock.json') or p.startswith('research/V03_') or p.startswith('research/V02_')}
changed=[p for p,h in protected.items() if not (root/p).exists() or sha((root/p).read_bytes())!=h]
local=json.loads(Path('build/v04-analysis/local-cold.json').read_bytes())
differences={p:{'tested':h,'current':sha((root/p).read_bytes())} for p,h in local['source_sha256'].items() if sha((root/p).read_bytes())!=h}
if changed:raise RuntimeError(('HISTORICAL_CHANGE',changed))
if set(differences)!={'tools/ci_entry.py','tools/v04_ci_probe.py'}:raise RuntimeError(('UNEXPECTED_SOURCE_DIFFERENCE',differences))
result={'starting_sha':start,'protected_sha256':protected,'changed':changed,'local_tested_sha':local['checkout']['head'],
 'local_to_delivery_python_differences':differences,'guardian_and_functional_harness_byte_identical':True,
 'tracked_changes':subprocess.check_output(['git','diff','--name-status',start]).decode().splitlines(),
 'untracked':subprocess.check_output(['git','ls-files','--others','--exclude-standard']).decode().splitlines()}
Path('build/v04-analysis/preservation.json').write_bytes(json.dumps(result,sort_keys=True,indent=2).encode()+b'\n')
print(json.dumps({'protected_files':len(protected),'changed':changed,'python_differences':list(differences)}))
